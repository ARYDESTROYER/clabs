# Activity 3 Quickstart

```bash
cd /home/labDirectory
labfctl set evil.attacker.local admin-b
fetch-sim evil.attacker.local /admin
fetch-sim evil.attacker.local /healthz
```

Hints:
- `/admin` is expected to be blocked.
- Inspect response headers from alternate endpoints.

Submit only the recovered token in `SUBMIT_FLAG.txt`.
