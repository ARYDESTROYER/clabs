# Activity 1 Quickstart

```bash
cd /home/labDirectory
labfctl status
fetch-sim evil.attacker.local /admin
labfctl set evil.attacker.local admin-a
fetch-sim evil.attacker.local /admin
```

Browser UI: `http://127.0.0.1:8080`

Submit only the recovered token in `SUBMIT_FLAG.txt`.
