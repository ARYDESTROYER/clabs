# Steganography & Forensics Lab

My friend has hidden six fragments in seemingly normal files as a challenge to me! Each fragment is meaningless on its own just a shard of an encoded message. But when you combine the fragments and decode them you will find the true message revealed!


## Challenge Description
A secret message has been split into 6 fragments and hidden across multiple files using various steganography techniques. Each fragment is a piece of an encoded string. You must:

1. Extract all 6 fragments from the provided files
2. Reconstruct the complete base64 string (order matters!)
3. Decode the string using appropriate decoding to reveal the secret message



## Objective
Multiple fragments of an encoded secret are hidden across various files using many stegoanography techniques. Extract all the fragments, reconstruct the encoded string, decode it and submit the string. Think of what kind of encoding would likely have been used after looking at the encoded string

## Files Provided
```
files/
├── vacation.jpg        - Personal photo
├── document.pdf        - Corporate document  
├── logo.png           - Company logo
├── announcement.wav   - Audio announcement
├── family_photo.jpg   - Family picture
└── firmware.bin       - Binary firmware file
```

## Tools Required
- `exiftool` - Metadata analysis
- `binwalk` - Binary analysis and extraction
- `zsteg` - PNG steganography detection
- `steghide` - Steganography extraction
- `audacity` or `sox` - Audio analysis
- `strings` - Binary string extraction

## Getting Started
1. Examine each file type
2. Think about what steganography technique suits each format
3. Document your findings
4. Remember: one file may hold the key to another!

