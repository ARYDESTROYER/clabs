#!/usr/bin/env python3
import os
import re
import json
import hashlib
from collections import Counter

# ===== Configuration =====
FLAG_FILE = "/tmp/student_flags.txt" 
OUTPUT_JSON = "/home/.evaluationScripts/evaluate.json"


FLAG_FILE = "./SUBMIT_FLAGS_HERE.txt"
OUTPUT_JSON = "./evaluate.json"

# Expected SHA256 digests (hex) for each fragment
EXPECTED_FRAGMENT_HASHES = {
    1: "1096ea36f81ed7a4950e73f4acb9bc5479e1595d978a85faa1249b4a98122650",
    2: "a09ac8146652c3c5294366895be6d8ef4e6f3db20f25ec1f12cf966a23b260f3",
    3: "3dc13aa6e1229c6ae89b7f65498cda539bc6deb943444d10ec71c4c7a01c99c1",
    4: "83f5350499d977540d51dc47eb79ee5dc55c3811d723b138209befd78b2a23b1",
    5: "a2bb6cba9c940101566181a2b5058038dc4a30533d4c9b6cdbf5fca4eee4912d",
    6: "be752056bddd66fb9db3e28c839d744569487db9d9018cff2925eeea25820c1b",
}

# Expected hash for the final decoded flag
EXPECTED_FINAL_FLAG_HASH = "e2aa5e1a25e930ac21798d0c699b717554dc8c0ba4c2f1f08aa9de3ac5125e34"

MAX_MARKS = 7  # 6 fragments + 1 final flag

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def extract_fragments_from_file(path: str) -> dict:
    """
    Extract fragment values from the submission file.
    Returns a dict with keys 1-6 for fragments and 'final' for the final flag.
    """
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    
    fragments = {}
    current_fragment = None
    
    for line in lines:
        line_stripped = line.strip()
        
        # Check for fragment headers
        if line_stripped.startswith("Fragment 1:"):
            current_fragment = 1
            value = line_stripped.replace("Fragment 1:", "").strip()
            if value:
                fragments[1] = value
        elif line_stripped.startswith("Fragment 2:"):
            current_fragment = 2
            value = line_stripped.replace("Fragment 2:", "").strip()
            if value:
                fragments[2] = value
        elif line_stripped.startswith("Fragment 3:"):
            current_fragment = 3
            value = line_stripped.replace("Fragment 3:", "").strip()
            if value:
                fragments[3] = value
        elif line_stripped.startswith("Fragment 4:"):
            current_fragment = 4
            value = line_stripped.replace("Fragment 4:", "").strip()
            if value:
                fragments[4] = value
        elif line_stripped.startswith("Fragment 5") and "Password" in line_stripped:
            current_fragment = 5
            value = re.sub(r"Fragment 5.*?:", "", line_stripped).strip()
            if value:
                fragments[5] = value
        elif line_stripped.startswith("Fragment 6:"):
            current_fragment = 6
            value = line_stripped.replace("Fragment 6:", "").strip()
            if value:
                fragments[6] = value
        elif line_stripped.startswith("Final Decoded Flag:"):
            current_fragment = 'final'
            value = line_stripped.replace("Final Decoded Flag:", "").strip()
            if value:
                fragments['final'] = value
        elif current_fragment is not None and line_stripped:
            # If we have a current fragment and the line is not empty,
            # it might be a continuation (multi-line value)
            if current_fragment not in fragments:
                fragments[current_fragment] = line_stripped
    
    return fragments

def check_fragments(fragments: dict) -> tuple[int, list[str]]:
    """
    Check each fragment against expected hashes.
    Returns (score, feedback_messages)
    """
    score = 0
    feedback = []
    
    # Check each fragment
    for i in range(1, 7):
        if i in fragments:
            user_input = fragments[i]
            feedback.append(f"Fragment {i} input: {user_input}")
            
            user_hash = sha256_hex(user_input)
            if user_hash == EXPECTED_FRAGMENT_HASHES[i]:
                feedback.append(f"Fragment {i} is correct ✓")
                score += 1
            else:
                feedback.append(f"Fragment {i} is incorrect ✗")
        else:
            feedback.append(f"Fragment {i}: Not submitted")
    
    # Check final flag
    feedback.append("")  # Empty line for separation
    if 'final' in fragments:
        final_input = fragments['final']
        feedback.append(f"Final Decoded Flag input: {final_input}")
        
        final_hash = sha256_hex(final_input)
        if final_hash == EXPECTED_FINAL_FLAG_HASH:
            feedback.append("Final Decoded Flag is correct ✓")
            score += 1
        else:
            feedback.append("Final Decoded Flag is incorrect ✗")
    else:
        feedback.append("Final Decoded Flag: Not submitted")
    
    return score, feedback

def main():
    results = {"data": []}
    test_result = {
        "testid": 1,
        "status": "failure",
        "score": 0,
        "maximum marks": MAX_MARKS,
        "message": "Submission incomplete or incorrect",
    }
    
    feedback_lines = []
    
    try:
        if not os.path.exists(FLAG_FILE):
            test_result["message"] = f"File {FLAG_FILE} not found."
            feedback_lines.append(test_result["message"])
        else:
            fragments = extract_fragments_from_file(FLAG_FILE)
            
            if not fragments:
                test_result["message"] = "No fragments found in submission file."
                feedback_lines.append(test_result["message"])
            else:
                score, feedback = check_fragments(fragments)
                feedback_lines = feedback
                
                test_result["score"] = score
                if score == MAX_MARKS:
                    test_result["status"] = "success"
                    test_result["message"] = "All fragments and final flag correct!"
                elif score > 0:
                    test_result["status"] = "partial"
                    test_result["message"] = f"{score}/{MAX_MARKS} correct."
                else:
                    test_result["status"] = "failure"
                    test_result["message"] = "No correct submissions."
    
    except Exception as e:
        test_result["message"] = f"Error reading submission: {str(e)}"
        feedback_lines.append(test_result["message"])
    
    # Add feedback to message
    if feedback_lines:
        test_result["message"] = "\n".join(feedback_lines)
    
    results["data"].append(test_result)
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_JSON), exist_ok=True)
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    
    # Print feedback to console
    print(f"Score: {test_result['score']}/{MAX_MARKS}")
    print("\nDetailed Feedback:")
    for line in feedback_lines:
        print(line)

if __name__ == "__main__":
    main()

