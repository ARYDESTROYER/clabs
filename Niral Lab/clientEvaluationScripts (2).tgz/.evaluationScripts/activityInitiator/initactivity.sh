#!/bin/bash
# Remove set -e to prevent the script from aborting on minor errors.
# We will handle critical errors manually.
# set -e 

echo "[+] Initializing Crypto Activity..."

# --- PART 1: INFRASTRUCTURE & PERMISSIONS (Critical) ---

# 1. Setup Evaluation Permissions (Fixes the Autograder PermissionError)
# Pre-create evaluate.json and set permissions so student/autograder can write to it
sudo touch /home/.evaluationScripts/evaluate.json
sudo chmod 666 /home/.evaluationScripts/evaluate.json

# Ensure the .evaluationScripts folder is traverseable/readable
sudo chmod -R 777 /home/.evaluationScripts || true

# 2. Setup Student Submission File
# Ensure the submission file exists and is writable by the student
sudo touch /home/labDirectory/SUBMIT_FLAGS_HERE.txt
sudo chmod 777 /home/labDirectory/SUBMIT_FLAGS_HERE.txt
