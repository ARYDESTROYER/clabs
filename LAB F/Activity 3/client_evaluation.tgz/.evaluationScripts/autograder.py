#!/usr/bin/env python3
# LAB F Activity 3 autograder. Flag-only grading: 100 points if flag.txt
# matches the expected secret, 0 otherwise.

import json
import os

OUTPUT_JSON = "/tmp/evaluate.json"
SUBMISSION = "/tmp/flag.txt"
EXPECTED_FLAG = "IITB{labf_a3_independent_pwn_complete}"

results = {"data": []}

t1 = {"testid": 1, "status": "failure", "score": 0, "maximum marks": 100,
      "message": "flag.txt is missing or wrong."}
try:
    if os.path.exists(SUBMISSION):
        submitted = open(SUBMISSION, "r", encoding="utf-8").read().strip()
        if submitted == EXPECTED_FLAG:
            t1["status"] = "success"
            t1["score"] = 100
            t1["message"] = "flag.txt matches FLAG3."
        elif submitted:
            t1["message"] = "flag.txt does not match the expected secret."
        else:
            t1["message"] = "flag.txt is empty."
    else:
        t1["message"] = "flag.txt not found in /home/labDirectory."
except Exception as exc:
    t1["message"] = "Evaluator error in test 1: {}".format(exc)
results["data"].append(t1)

with open(OUTPUT_JSON, "w", encoding="utf-8") as fh:
    json.dump(results, fh, indent=2)

total = sum(t["score"] for t in results["data"])
maxs = sum(t["maximum marks"] for t in results["data"])
print("Score: {}/{}".format(total, maxs))
for t in results["data"]:
    print("Test {} [{}]: {}".format(t["testid"], t["status"], t["message"]))
